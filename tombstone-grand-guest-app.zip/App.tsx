import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import HotelInfo from './pages/HotelInfo';
import Marketplace from './pages/Marketplace';
import BeerWine from './pages/BeerWine';
import Dining from './pages/Dining';
import Attractions from './pages/Attractions';
import Contact from './pages/Contact';
import Events from './pages/Events';

const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout><Home /></Layout>} />
        <Route path="/stay" element={<Layout title="Your Stay"><HotelInfo /></Layout>} />
        <Route path="/marketplace" element={<Layout title="Marketplace"><Marketplace /></Layout>} />
        <Route path="/beer-wine" element={<Layout title="Beer & Wine"><BeerWine /></Layout>} />
        <Route path="/dining" element={<Layout title="Local Dining"><Dining /></Layout>} />
        <Route path="/explore" element={<Layout title="Explore"><Attractions /></Layout>} />
        <Route path="/contact" element={<Layout title="Contact Us"><Contact /></Layout>} />
        <Route path="/events" element={<Layout title="Events & Tips"><Events /></Layout>} />
      </Routes>
    </Router>
  );
};

export default App;