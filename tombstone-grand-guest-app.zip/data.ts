import { Wifi, Clock, Ban, Dog, BatteryCharging, Coffee, Waves, Snowflake, Flame, Leaf, Tv, Key, Wrench, Lock, Zap, Smartphone, Film, Footprints, Star, Accessibility, ArrowUpCircle } from 'lucide-react';

export const HOTEL_NAME = "Tombstone Grand Hotel";
export const BRAND_NAME = "Baymont by Wyndham";
export const ADDRESS = "580 W Randolph Way, Tombstone, AZ 85638";

export const WELCOME_MESSAGE = {
  title: `Welcome to ${HOTEL_NAME}, a ${BRAND_NAME}.`,
  subtitle: "We are happy to have you.",
  text: "Use this guide to enjoy your stay and explore Tombstone."
};

export const HOTEL_INFO = [
  { label: "Check-in", value: "3:00 PM", icon: Clock },
  { label: "Check-out", value: "11:00 AM", icon: Clock },
  { label: "WiFi Name", value: "wyndhamWifi", icon: Wifi },
  { label: "WiFi Password", value: "grandhotel", icon: Wifi },
  { label: "Breakfast", value: "6:30 AM - 9:30 AM", icon: Coffee },
  { label: "Pool", value: "10:00 AM - 10:00 PM", icon: Waves },
  { label: "Pool Towels", value: "Available at pool rack outside", icon: Waves },
  { label: "Ice Machines", value: "Two machines, one on each floor", icon: Snowflake },
  { label: "Firepit", value: "Located on north side of property", icon: Flame },
  { label: "Quiet Hours", value: "Please respect other guests", icon: Ban },
  { label: "Smoking", value: "Non-smoking property", icon: Ban },
  { label: "Pets", value: "Pet friendly (Ground floor only)", icon: Dog },
  { label: "EV Charging", value: "Tesla charger for guests", icon: BatteryCharging },
];

export const BREAKFAST_DETAILS = {
  time: "6:30 AM - 9:30 AM",
  items: [
    "Scrambled Eggs",
    "Sausages",
    "Waffles",
    "Coffee & Juice",
    "Yogurt",
    "Bread & Bagels"
  ]
};

export const IMPORTANT_NOTICES = [
  {
    title: "No Elevator Access",
    text: "We do not have an elevator. If you require a ground floor room, please let us know in advance so we can make arrangements.",
    icon: Accessibility
  },
  {
    title: "Pet Policy Detail",
    text: "We are a pet-friendly hotel! Please note that pets are allowed on the ground floor only. Notify us early to ensure a ground floor room is available.",
    icon: Dog
  }
];

export const GOOGLE_REVIEW_LINK = "https://g.page/r/CdMu_RAsng9VEAE/review";
export const BOOKING_LINK = "https://www.wyndhamhotels.com/baymont/tombstone-arizona/tombstone-grand-hotel-a-baymont/overview?PS:e770esn4cq8v609&adobe=koddiPPC_hotelcode=WYNDHAM-91952_hotelid=58835_23201497800&gad_source=1&gad_campaignid=23201497800&gbraid=0AAAAADjacG3jidg7qp-jPXZMItqbR4Aos&gclid=Cj0KCQiAuvTJBhCwARIsAL6DemgdnggCzIymeh8V0dHIV1PGGe8jJbHtcHl8OyTvowab6JtHDY50nEgaAvTGEALw_wcB";

export const HOUSEKEEPING_POLICY = {
  title: "Wyndham Green Program",
  text: "To support our sustainability efforts, we do not offer daily full housekeeping service. We follow the Wyndham Green Program where full service is provided every 3rd day of your stay. If you need fresh towels, amenities, or anything else in between, please simply ask the front desk.",
  icon: Leaf
};

export const MAINTENANCE_LINK = "https://forms.gle/6LGXKTZPypqj92jbA";

export const TV_GUIDE = {
  title: "TV & DirecTV Guide",
  steps: [
    "Remote is paired with both TV and DirecTV box.",
    "If TV won't turn on: Check that power cables behind TV are plugged in.",
    "TV Input: Ensure TV is set to HDMI 1.",
    "If DirecTV box freezes: Unplug power cord from box, wait 10 seconds, then plug back in.",
    "Still need help? Dial 0 for Front Desk."
  ],
  icon: Tv
};

export const ROOM_TIPS = [
  {
    title: "Microwave Safety",
    text: "Microwave has a child safety lock. Press the 'Unlock' button before opening the door.",
    icon: Lock
  },
  {
    title: "Alarm Clock USB",
    text: "To use the USB charger, slide the switch on the right side all the way to 'FM'.",
    icon: Smartphone
  },
  {
    title: "Room Keys",
    text: "Keep keys away from mobile phones and magnetic cards to prevent deactivation.",
    icon: Key
  }
];

export const LOCAL_EVENTS = [
  {
    title: "Daily Gunfights",
    description: "Reenactments happen daily at the O.K. Corral and other locations. Check schedules on Allen Street.",
    icon: Star,
    color: "border-[#00a3e0]"
  },
  {
    title: "Walking Tours",
    description: "Ghost tours and historical walks are available every evening.",
    icon: Footprints,
    color: "border-[#002d72]"
  },
  {
    title: "Friday Night Movies",
    description: "Join us for movies and popcorn every Friday night in the lobby!",
    icon: Film,
    color: "border-amber-500"
  }
];

export const MARKETPLACE_ITEMS = [
  "Cold drinks",
  "Snacks and treats",
  "Ice cream",
  "Personal care items",
  "Travel essentials"
];

export const DINING_OPTIONS = [
  {
    name: "Big Nose Kate’s Saloon",
    type: "Western food and live music",
    description: "Historic saloon atmosphere.",
    mapQuery: "Big Nose Kate's Saloon Tombstone"
  },
  {
    name: "Crystal Palace Saloon",
    type: "Historic saloon and American food",
    description: "Step back in time.",
    mapQuery: "Crystal Palace Saloon Tombstone"
  },
  {
    name: "O.K. Cafe",
    type: "Casual dining",
    description: "Great for breakfast and lunch.",
    mapQuery: "O.K. Cafe Tombstone"
  },
  {
    name: "The Depot Steakhouse",
    type: "Steaks and fine dining",
    description: "Located nearby.",
    mapQuery: "The Depot Steakhouse Tombstone"
  },
  {
    name: "Old Tombstone Western Theme Restaurant",
    type: "Western Theme",
    description: "Fun atmosphere.",
    mapQuery: "Old Tombstone Western Theme Restaurant"
  }
];

export const ATTRACTIONS = [
  {
    name: "O.K. Corral",
    description: "Historic gunfight location.",
    mapQuery: "O.K. Corral Tombstone"
  },
  {
    name: "Boothill Graveyard",
    description: "Famous old west cemetery.",
    mapQuery: "Boothill Graveyard Tombstone"
  },
  {
    name: "Bird Cage Theatre",
    description: "Historic theater and saloon.",
    mapQuery: "Bird Cage Theatre Tombstone"
  },
  {
    name: "Tombstone Courthouse",
    description: "State Historic Park & Museum.",
    mapQuery: "Tombstone Courthouse State Historic Park"
  },
  {
    name: "Allen Street",
    description: "Main walking area with shops.",
    mapQuery: "Allen Street Tombstone"
  }
];

export const EVENTS_TIP = "Ask the front desk about today’s events, gunfight reenactments, and walking tours in Tombstone.";

export const CHAMBER_LINKS = [
  { label: "Visitor FAQs", url: "https://tombstonechamber.com/tombstone-az-faqs-for-visitors/" },
  { label: "Places to Eat & Drink", url: "https://tombstonechamber.com/directory/places-to-eat-and-drink-in-tombstone-az/" },
  { label: "Community Events", url: "https://tombstonechamber.com/tombstone-community-events/" },
  { label: "Tombstone History", url: "https://tombstonechamber.com/about-tombstone-az/tombstone-history/" }
];

export const CONTACT_INFO = {
  phone: "520-457-9507", // Placeholder or real if known, using generic format
  email: "frontdesk@tombstonegrand.com", // Placeholder
  addressQuery: "Tombstone Grand Hotel"
};