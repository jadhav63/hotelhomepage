import React from 'react';
import { MARKETPLACE_ITEMS } from '../data';
import { ShoppingBasket } from 'lucide-react';

const Marketplace: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center space-y-4">
        <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto text-[#002d72]">
          <ShoppingBasket size={32} />
        </div>
        <h2 className="text-xl font-bold text-[#002d72]">Visit The Marketplace</h2>
        <p className="text-slate-600">
          Our Marketplace is located near the front desk and is open 24 hours.
        </p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 bg-[#002d72] text-white">
          <h3 className="font-bold">Available Items</h3>
        </div>
        <ul className="divide-y divide-slate-100">
          {MARKETPLACE_ITEMS.map((item, i) => (
            <li key={i} className="p-4 text-slate-700 font-medium pl-6 relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-[#00a3e0] rounded-full"></span>
              {item}
            </li>
          ))}
        </ul>
        <div className="p-6 bg-blue-50 text-center">
          <p className="text-[#002d72] font-semibold italic">
            "Perfect for a quick snack or a relaxing evening."
          </p>
        </div>
      </div>
    </div>
  );
};

export default Marketplace;