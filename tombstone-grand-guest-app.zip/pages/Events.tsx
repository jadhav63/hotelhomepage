import React from 'react';
import { EVENTS_TIP, LOCAL_EVENTS } from '../data';
import { Calendar, Info } from 'lucide-react';

const Events: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="bg-blue-100 p-2 rounded-lg text-[#002d72]">
            <Calendar size={24} />
          </div>
          <h2 className="font-bold text-xl text-slate-800">Local Events</h2>
        </div>
        
        <div className="space-y-4">
            {LOCAL_EVENTS.map((event, index) => (
              <div key={index} className={`p-4 bg-slate-50 rounded-xl border-l-4 ${event.color} flex gap-3`}>
                 <div className="mt-1 text-slate-500">
                    <event.icon size={20} />
                 </div>
                 <div>
                   <h3 className="font-bold text-slate-800">{event.title}</h3>
                   <p className="text-slate-600 text-sm mt-1">{event.description}</p>
                 </div>
              </div>
            ))}
        </div>

        <div className="mt-6 flex items-start gap-3 text-slate-600 bg-blue-50 p-4 rounded-xl">
            <Info className="shrink-0 text-[#002d72]" size={20} />
            <p className="text-sm font-medium">{EVENTS_TIP}</p>
        </div>
      </div>
    </div>
  );
};

export default Events;