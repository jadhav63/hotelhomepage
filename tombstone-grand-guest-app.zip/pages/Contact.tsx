import React from 'react';
import { CONTACT_INFO } from '../data';
import { Phone, Mail, Navigation } from 'lucide-react';

const Contact: React.FC = () => {
  const ActionButton = ({ href, icon: Icon, label, primary = false }: { href: string, icon: any, label: string, primary?: boolean }) => (
    <a
      href={href}
      target={href.startsWith('http') ? '_blank' : undefined}
      rel="noopener noreferrer"
      className={`flex items-center justify-center gap-3 p-4 rounded-xl font-bold shadow-sm transition-transform active:scale-95 ${
        primary 
          ? 'bg-[#002d72] text-white hover:bg-blue-900' 
          : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
      }`}
    >
      <Icon size={20} />
      <span>{label}</span>
    </a>
  );

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-slate-800">How can we help?</h2>
        <p className="text-slate-500 mt-2">Our front desk team is here for you 24/7.</p>
      </div>

      <div className="flex flex-col gap-4">
        <ActionButton 
          href={`tel:${CONTACT_INFO.phone.replace(/-/g, '')}`} 
          icon={Phone} 
          label="Call Front Desk" 
          primary 
        />
        
        <ActionButton 
          href={`mailto:${CONTACT_INFO.email}`} 
          icon={Mail} 
          label="Email Front Desk" 
        />
        
        <ActionButton 
          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(CONTACT_INFO.addressQuery)}`} 
          icon={Navigation} 
          label="Get Directions to Hotel" 
        />
      </div>
    </div>
  );
};

export default Contact;