import React from 'react';
import { HOTEL_INFO, HOUSEKEEPING_POLICY, MAINTENANCE_LINK, TV_GUIDE, ROOM_TIPS, BREAKFAST_DETAILS, IMPORTANT_NOTICES, GOOGLE_REVIEW_LINK, BOOKING_LINK } from '../data';
import { Info, Wrench, ExternalLink, Coffee, MessageSquare, CalendarCheck, AlertCircle } from 'lucide-react';

const HotelInfo: React.FC = () => {
  const policyKeys = ["Check-in", "Check-out", "Quiet Hours", "Smoking", "Pets"];
  
  const policies = HOTEL_INFO.filter(item => policyKeys.includes(item.label));
  // Filter out Breakfast from amenities list since we have a detailed section now.
  const amenities = HOTEL_INFO.filter(item => !policyKeys.includes(item.label) && item.label !== 'Breakfast');

  return (
    <div className="space-y-6">
      {/* Maintenance Request */}
      <a 
        href={MAINTENANCE_LINK}
        target="_blank"
        rel="noopener noreferrer"
        className="block bg-amber-50 border border-amber-200 p-4 rounded-2xl shadow-sm flex items-center justify-between active:scale-95 transition-transform"
      >
        <div className="flex items-center gap-3">
          <div className="bg-amber-100 p-2 rounded-lg text-amber-700">
            <Wrench size={24} />
          </div>
          <div>
            <h3 className="font-bold text-amber-900">Report Maintenance Issue</h3>
            <p className="text-amber-700 text-xs">Submit a request via Google Form</p>
          </div>
        </div>
        <ExternalLink size={20} className="text-amber-400" />
      </a>

      {/* Important Notices */}
      <div className="bg-rose-50 rounded-2xl shadow-sm border border-rose-100 overflow-hidden">
        <div className="p-4 bg-rose-100 border-b border-rose-200 flex items-center gap-2">
            <AlertCircle className="text-rose-600" size={20} />
            <h2 className="font-bold text-rose-800 text-lg">Important Notices</h2>
        </div>
        <div className="divide-y divide-rose-100">
          {IMPORTANT_NOTICES.map((notice, index) => (
            <div key={index} className="p-4 flex items-start gap-4">
               <div className="bg-white p-2 rounded-lg text-rose-500 shrink-0 shadow-sm">
                  <notice.icon size={20} />
               </div>
               <div>
                 <h3 className="font-bold text-rose-900 text-sm">{notice.title}</h3>
                 <p className="text-rose-700 text-sm mt-1 leading-relaxed">{notice.text}</p>
               </div>
            </div>
          ))}
        </div>
      </div>

      {/* Breakfast Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 bg-orange-50 border-b border-orange-100 flex items-center gap-3">
          <div className="bg-orange-100 p-2 rounded-full text-orange-600">
            <Coffee size={24} />
          </div>
          <div>
            <h2 className="font-bold text-orange-900 text-lg">Hot Breakfast</h2>
            <p className="text-orange-700 text-xs font-bold uppercase tracking-wide">{BREAKFAST_DETAILS.time}</p>
          </div>
        </div>
        <div className="p-4">
          <div className="flex flex-wrap gap-2">
            {BREAKFAST_DETAILS.items.map((item, i) => (
              <span key={i} className="bg-orange-50 text-orange-800 px-3 py-1 rounded-full text-sm font-medium border border-orange-100">
                {item}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Amenities Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-100">
          <h2 className="font-bold text-[#002d72] text-lg">Guest Services & Amenities</h2>
        </div>
        <div className="divide-y divide-slate-100">
          {amenities.map((item, index) => (
            <div key={index} className="p-4 flex items-center gap-4">
              <div className="bg-blue-50 p-3 rounded-full text-[#002d72]">
                <item.icon size={20} />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium uppercase tracking-wide">{item.label}</p>
                <p className="text-slate-800 font-semibold">{item.value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* TV Guide */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center gap-3">
          <TV_GUIDE.icon className="text-[#002d72]" size={24} />
          <h2 className="font-bold text-[#002d72] text-lg">{TV_GUIDE.title}</h2>
        </div>
        <div className="p-4">
          <ul className="space-y-3">
            {TV_GUIDE.steps.map((step, i) => (
              <li key={i} className="flex gap-3 text-sm text-slate-700">
                <span className="font-bold text-[#00a3e0]">{i + 1}.</span>
                <span>{step}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Room Tips */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-100">
          <h2 className="font-bold text-[#002d72] text-lg">In-Room Guide</h2>
        </div>
        <div className="divide-y divide-slate-100">
          {ROOM_TIPS.map((tip, index) => (
            <div key={index} className="p-4 flex items-start gap-4">
              <div className="bg-slate-100 p-2 rounded-lg text-slate-600 shrink-0">
                <tip.icon size={20} />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 text-sm">{tip.title}</h3>
                <p className="text-slate-600 text-sm mt-1">{tip.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Housekeeping Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 bg-green-50 border-b border-green-100 flex items-center gap-2">
            <HOUSEKEEPING_POLICY.icon className="text-green-600" size={20} />
            <h2 className="font-bold text-green-800 text-lg">{HOUSEKEEPING_POLICY.title}</h2>
        </div>
        <div className="p-5 text-slate-600 text-sm leading-relaxed">
            {HOUSEKEEPING_POLICY.text}
        </div>
      </div>

      {/* Policies Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
          <Info className="text-[#002d72]" size={20} />
          <h2 className="font-bold text-[#002d72] text-lg">Hotel Policies</h2>
        </div>
        <div className="divide-y divide-slate-100">
          {policies.map((item, index) => (
            <div key={index} className="p-4 flex items-center gap-4">
              <div className="bg-slate-100 p-3 rounded-full text-slate-600">
                <item.icon size={20} />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium uppercase tracking-wide">{item.label}</p>
                <p className="text-slate-800 font-semibold">{item.value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Feedback & Booking Links */}
      <div className="grid grid-cols-1 gap-4 pt-4">
        <a 
          href={GOOGLE_REVIEW_LINK} 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-white border-2 border-slate-100 rounded-2xl p-4 flex items-center justify-center gap-3 text-slate-700 font-bold hover:bg-slate-50 transition-colors shadow-sm active:scale-95"
        >
          <MessageSquare size={20} className="text-[#00a3e0]" />
          Leave a Google Review
        </a>

        <a 
          href={BOOKING_LINK} 
          target="_blank" 
          rel="noopener noreferrer"
          className="bg-[#002d72] rounded-2xl p-4 flex items-center justify-center gap-3 text-white font-bold hover:bg-blue-900 transition-colors shadow-md active:scale-95"
        >
          <CalendarCheck size={20} />
          Book Your Next Stay
        </a>
      </div>
    </div>
  );
};

export default HotelInfo;