import React from 'react';
import { Wine, AlertCircle } from 'lucide-react';

const BeerWine: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 text-center space-y-6">
        <div className="bg-rose-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto text-rose-500">
          <Wine size={40} />
        </div>
        
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-[#002d72]">Beer & Wine</h2>
          <p className="text-slate-600 font-medium">Available at the Front Desk Marketplace</p>
        </div>

        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-left flex gap-3">
          <AlertCircle className="text-rose-500 shrink-0" size={24} />
          <div className="space-y-1">
            <p className="font-bold text-slate-800">Age Restriction</p>
            <p className="text-sm text-slate-600">Must be 21 years or older. Valid government-issued ID is required at purchase.</p>
          </div>
        </div>

        <p className="text-[#00a3e0] font-medium italic">
          "Grab a cold drink and unwind after a day exploring Tombstone."
        </p>
      </div>
    </div>
  );
};

export default BeerWine;