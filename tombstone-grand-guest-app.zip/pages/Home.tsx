import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BedDouble, ShoppingBag, Wine, Utensils, Map, Phone, Calendar } from 'lucide-react';
import { WELCOME_MESSAGE, HOTEL_NAME, ADDRESS } from '../data';

const Home: React.FC = () => {
  const navigate = useNavigate();

  const MenuButton = ({ to, icon: Icon, label, color = "bg-white" }: { to: string, icon: any, label: string, color?: string }) => (
    <button
      onClick={() => navigate(to)}
      className={`${color} hover:brightness-95 active:scale-95 transition-all duration-200 p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center justify-center gap-3 text-center h-32 w-full`}
    >
      <Icon size={32} className="text-[#002d72]" />
      <span className="font-bold text-slate-700 text-sm leading-tight">{label}</span>
    </button>
  );

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center space-y-3">
        <h2 className="text-[#002d72] font-bold text-xl">{HOTEL_NAME}</h2>
        <p className="text-slate-500 text-sm font-medium -mt-1">{ADDRESS}</p>
        <div className="h-0.5 w-16 bg-[#00a3e0] mx-auto rounded-full my-2"></div>
        <p className="text-slate-600 font-medium">{WELCOME_MESSAGE.subtitle}</p>
        <p className="text-slate-500 text-sm">{WELCOME_MESSAGE.text}</p>
      </div>

      {/* Grid Menu */}
      <div className="grid grid-cols-2 gap-4">
        <MenuButton to="/stay" icon={BedDouble} label="Your Stay" />
        <MenuButton to="/marketplace" icon={ShoppingBag} label="Marketplace" />
        <MenuButton to="/beer-wine" icon={Wine} label="Beer & Wine" />
        <MenuButton to="/dining" icon={Utensils} label="Eat Local" />
        <MenuButton to="/explore" icon={Map} label="Explore" />
        <MenuButton to="/contact" icon={Phone} label="Contact Us" />
      </div>

      {/* Events Banner */}
      <button 
        onClick={() => navigate('/events')}
        className="w-full bg-gradient-to-r from-[#002d72] to-[#1e40af] text-white p-4 rounded-2xl shadow-md flex items-center justify-between px-6 active:scale-95 transition-transform"
      >
        <div className="flex flex-col items-start">
          <span className="font-bold">Events & Local Tips</span>
          <span className="text-xs text-blue-200">See what's happening today</span>
        </div>
        <Calendar className="opacity-80" />
      </button>
    </div>
  );
};

export default Home;