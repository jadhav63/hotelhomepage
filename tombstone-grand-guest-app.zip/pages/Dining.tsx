import React from 'react';
import { DINING_OPTIONS } from '../data';
import { MapPin, Utensils } from 'lucide-react';

const Dining: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="text-center space-y-2 mb-6">
        <h2 className="text-xl font-bold text-[#002d72]">Eat Local In Tombstone</h2>
        <p className="text-slate-600 text-sm">Enjoy local dining just minutes from the hotel.</p>
      </div>

      <div className="space-y-4">
        {DINING_OPTIONS.map((place, i) => (
          <a
            key={i}
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(place.mapQuery)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="block bg-white p-4 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow active:scale-[0.99]"
          >
            <div className="flex justify-between items-start gap-4">
              <div className="space-y-1">
                <h3 className="font-bold text-slate-800 text-lg">{place.name}</h3>
                <div className="flex items-center gap-2 text-[#00a3e0] text-sm font-medium">
                  <Utensils size={14} />
                  <span>{place.type}</span>
                </div>
                <p className="text-slate-500 text-sm">{place.description}</p>
              </div>
              <div className="bg-blue-50 p-2 rounded-full text-[#002d72] shrink-0">
                <MapPin size={20} />
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};

export default Dining;