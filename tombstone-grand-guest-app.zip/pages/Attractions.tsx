import React, { useState } from 'react';
import { ATTRACTIONS, CHAMBER_LINKS } from '../data';
import { Map, ExternalLink, Search, Info } from 'lucide-react';

const Attractions: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredAttractions = ATTRACTIONS.filter(spot => 
    spot.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    spot.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2 mb-6">
        <h2 className="text-xl font-bold text-[#002d72]">Explore Tombstone</h2>
        <p className="text-slate-600 text-sm">
          Tombstone is rich in history and western culture. These are guest favorites.
        </p>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search size={20} className="text-slate-400" />
        </div>
        <input
          type="text"
          placeholder="Search attractions..."
          className="block w-full pl-10 pr-3 py-3 border border-slate-200 rounded-xl leading-5 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#002d72] focus:border-transparent shadow-sm"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="space-y-4">
        {filteredAttractions.length > 0 ? (
          filteredAttractions.map((spot, i) => (
            <a
              key={i}
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(spot.mapQuery)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-white group rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-all"
            >
              <div className="p-5 flex flex-col gap-2">
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-slate-800 text-lg group-hover:text-[#002d72] transition-colors">
                    {spot.name}
                  </h3>
                  <ExternalLink size={16} className="text-slate-300 group-hover:text-[#00a3e0]" />
                </div>
                <p className="text-slate-500 text-sm">{spot.description}</p>
                <div className="flex items-center gap-1.5 text-[#00a3e0] text-xs font-bold uppercase tracking-wider mt-2">
                  <Map size={14} />
                  <span>Get Directions</span>
                </div>
              </div>
            </a>
          ))
        ) : (
          <div className="text-center py-8 text-slate-500 bg-white rounded-2xl border border-slate-100">
            <p>No attractions found matching "{searchQuery}"</p>
          </div>
        )}
      </div>

      {/* Chamber Links Section */}
      <div className="mt-8 pt-6 border-t border-slate-200 space-y-4">
        <div className="flex items-center gap-2 px-2">
            <Info size={20} className="text-[#002d72]" />
            <h3 className="font-bold text-slate-800">Official Visitor Info</h3>
        </div>
        <div className="grid gap-3">
            {CHAMBER_LINKS.map((link, i) => (
                <a 
                    key={i}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-4 bg-blue-50 border border-blue-100 rounded-xl text-[#002d72] font-medium hover:bg-blue-100 transition-colors shadow-sm active:scale-[0.99]"
                >
                    <span>{link.label}</span>
                    <ExternalLink size={16} className="opacity-70" />
                </a>
            ))}
        </div>
        <p className="text-xs text-slate-400 text-center mt-2">
            Information provided by Tombstone Chamber of Commerce
        </p>
      </div>
    </div>
  );
};

export default Attractions;