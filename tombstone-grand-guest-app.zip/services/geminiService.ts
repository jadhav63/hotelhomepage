import { GoogleGenAI } from "@google/genai";
import { HOTEL_INFO, DINING_OPTIONS, ATTRACTIONS, MARKETPLACE_ITEMS, CONTACT_INFO, HOUSEKEEPING_POLICY, TV_GUIDE, ROOM_TIPS, MAINTENANCE_LINK, BREAKFAST_DETAILS, LOCAL_EVENTS, IMPORTANT_NOTICES, GOOGLE_REVIEW_LINK, BOOKING_LINK } from '../data';

// Prepare context for the AI
const SYSTEM_INSTRUCTION = `
You are the Virtual Concierge for Tombstone Grand Hotel, a Baymont by Wyndham.
Your goal is to be friendly, helpful, and professional.
Answer guest questions based ONLY on the following information. If you don't know, suggest they contact the front desk.

HOTEL INFO:
${JSON.stringify(HOTEL_INFO)}

IMPORTANT NOTICES (Elevator/Pets):
${JSON.stringify(IMPORTANT_NOTICES)}

BREAKFAST:
Time: ${BREAKFAST_DETAILS.time}
Items: ${BREAKFAST_DETAILS.items.join(', ')}

MAINTENANCE:
Guests can report issues here: ${MAINTENANCE_LINK}

TV GUIDE & TROUBLESHOOTING:
${JSON.stringify(TV_GUIDE)}

IN-ROOM TIPS (Microwave, Alarm Clock, Keys):
${JSON.stringify(ROOM_TIPS)}

EVENTS:
${JSON.stringify(LOCAL_EVENTS)}

HOUSEKEEPING POLICY:
${HOUSEKEEPING_POLICY.title}: ${HOUSEKEEPING_POLICY.text}

MARKETPLACE ITEMS:
${MARKETPLACE_ITEMS.join(', ')}

DINING:
${JSON.stringify(DINING_OPTIONS)}

ATTRACTIONS:
${JSON.stringify(ATTRACTIONS)}

LINKS:
Review Link: ${GOOGLE_REVIEW_LINK}
Booking Link: ${BOOKING_LINK}

CONTACT:
Phone: ${CONTACT_INFO.phone}
Address: ${CONTACT_INFO.addressQuery}

Keep answers short and mobile-friendly.
`;

let ai: GoogleGenAI | null = null;
try {
  if (process.env.API_KEY) {
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
} catch (e) {
  console.error("Failed to initialize Gemini", e);
}

export const sendMessageToGemini = async (message: string, history: {role: 'user' | 'model', parts: {text: string}[]}[]): Promise<string> => {
  if (!ai) return "I'm sorry, I am currently offline. Please contact the front desk.";

  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
      history: history
    });

    const result = await chat.sendMessage({ message });
    return result.text || "I didn't quite catch that. Could you ask the front desk?";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having trouble connecting right now. Please try again later or ask the front desk.";
  }
};