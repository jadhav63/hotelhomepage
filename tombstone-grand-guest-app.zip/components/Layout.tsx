import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ChevronLeft, Home } from 'lucide-react';
import Concierge from './Concierge';

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
}

const Layout: React.FC<LayoutProps> = ({ children, title }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const isHome = location.pathname === '/';

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col max-w-md mx-auto shadow-2xl relative">
      {/* Header */}
      <header className="bg-[#002d72] text-white p-4 sticky top-0 z-40 shadow-md">
        <div className="flex items-center justify-between">
          {!isHome ? (
            <button 
              onClick={() => navigate(-1)}
              className="p-1 hover:bg-white/10 rounded-full transition-colors"
              aria-label="Go back"
            >
              <ChevronLeft size={28} />
            </button>
          ) : (
            <div className="w-8" /> // Spacer
          )}
          
          <h1 className="font-bold text-lg text-center truncate px-2">
            {title || "Tombstone Grand"}
          </h1>

          {!isHome ? (
            <button 
              onClick={() => navigate('/')}
              className="p-1 hover:bg-white/10 rounded-full transition-colors"
              aria-label="Go home"
            >
              <Home size={24} />
            </button>
          ) : (
            <div className="w-8" /> // Spacer
          )}
        </div>
        {isHome && (
          <div className="text-center mt-2 text-xs text-blue-200 uppercase tracking-widest">
            Baymont by Wyndham
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow p-4 overflow-y-auto pb-24">
        {children}
      </main>

      {/* Concierge Button */}
      <Concierge />
    </div>
  );
};

export default Layout;